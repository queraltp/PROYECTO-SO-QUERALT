﻿
namespace Version1
{
    partial class IniciarSesion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.usuario_Box = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.inicioSesion = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.Desconectar = new System.Windows.Forms.Button();
            this.AceptarConsulta = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.AceptarRegistro = new System.Windows.Forms.Button();
            this.contraseñaIn = new System.Windows.Forms.TextBox();
            this.usuarioIn = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Jugar = new System.Windows.Forms.Button();
            this.nombre_invitado_Box = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.MensajeBox = new System.Windows.Forms.TextBox();
            this.EnviarMensaje = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.RecibeTexto = new System.Windows.Forms.RichTextBox();
            this.TiempoChat = new System.Windows.Forms.Timer(this.components);
            this.AcabarChatBtn = new System.Windows.Forms.Button();
            this.radioButtonConsulta2 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(22, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(384, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Introduce los datos para iniciar sesión en el juego:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Usuario:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Contraseña:";
            // 
            // usuario_Box
            // 
            this.usuario_Box.Location = new System.Drawing.Point(154, 72);
            this.usuario_Box.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.usuario_Box.Name = "usuario_Box";
            this.usuario_Box.Size = new System.Drawing.Size(124, 22);
            this.usuario_Box.TabIndex = 3;
            this.usuario_Box.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(154, 103);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(124, 22);
            this.textBox2.TabIndex = 4;
            // 
            // inicioSesion
            // 
            this.inicioSesion.Location = new System.Drawing.Point(94, 142);
            this.inicioSesion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.inicioSesion.Name = "inicioSesion";
            this.inicioSesion.Size = new System.Drawing.Size(117, 33);
            this.inicioSesion.TabIndex = 5;
            this.inicioSesion.Text = "Iniciar Sesión";
            this.inicioSesion.UseVisualStyleBackColor = true;
            this.inicioSesion.Click += new System.EventHandler(this.inicioSesion_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(22, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(285, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "No tienes una cuenta? Registrate ya!";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(569, 103);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(436, 204);
            this.dataGridView1.TabIndex = 27;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label5.Location = new System.Drawing.Point(566, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(284, 20);
            this.label5.TabIndex = 28;
            this.label5.Text = "Consulta aquí la lista de conectados:";
            // 
            // Desconectar
            // 
            this.Desconectar.Location = new System.Drawing.Point(952, 26);
            this.Desconectar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Desconectar.Name = "Desconectar";
            this.Desconectar.Size = new System.Drawing.Size(130, 33);
            this.Desconectar.TabIndex = 30;
            this.Desconectar.Text = "Desconectarme";
            this.Desconectar.UseVisualStyleBackColor = true;
            this.Desconectar.Click += new System.EventHandler(this.Desconectar_Click);
            // 
            // AceptarConsulta
            // 
            this.AceptarConsulta.Location = new System.Drawing.Point(112, 537);
            this.AceptarConsulta.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AceptarConsulta.Name = "AceptarConsulta";
            this.AceptarConsulta.Size = new System.Drawing.Size(87, 32);
            this.AceptarConsulta.TabIndex = 36;
            this.AceptarConsulta.Text = "Consultar";
            this.AceptarConsulta.UseVisualStyleBackColor = true;
            this.AceptarConsulta.Click += new System.EventHandler(this.AceptarConsulta_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(29, 441);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(173, 20);
            this.label8.TabIndex = 34;
            this.label8.Text = "Consultas sobre chat:";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(28, 477);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(250, 20);
            this.radioButton2.TabIndex = 32;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Consulta 1: Dime la duracion del chat.";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // AceptarRegistro
            // 
            this.AceptarRegistro.Location = new System.Drawing.Point(108, 371);
            this.AceptarRegistro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AceptarRegistro.Name = "AceptarRegistro";
            this.AceptarRegistro.Size = new System.Drawing.Size(91, 33);
            this.AceptarRegistro.TabIndex = 43;
            this.AceptarRegistro.Text = "Aceptar";
            this.AceptarRegistro.UseVisualStyleBackColor = true;
            this.AceptarRegistro.Click += new System.EventHandler(this.AceptarRegistro_Click);
            // 
            // contraseñaIn
            // 
            this.contraseñaIn.Location = new System.Drawing.Point(160, 331);
            this.contraseñaIn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.contraseñaIn.Name = "contraseñaIn";
            this.contraseñaIn.Size = new System.Drawing.Size(138, 22);
            this.contraseñaIn.TabIndex = 42;
            // 
            // usuarioIn
            // 
            this.usuarioIn.Location = new System.Drawing.Point(160, 295);
            this.usuarioIn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.usuarioIn.Name = "usuarioIn";
            this.usuarioIn.Size = new System.Drawing.Size(138, 22);
            this.usuarioIn.TabIndex = 41;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(72, 371);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 16);
            this.label9.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(54, 334);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 16);
            this.label10.TabIndex = 39;
            this.label10.Text = "Contraseña:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(68, 301);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 16);
            this.label11.TabIndex = 38;
            this.label11.Text = "Usuario:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(49, 264);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(223, 16);
            this.label12.TabIndex = 37;
            this.label12.Text = "Registrate para poder iniciar sesión:";
            // 
            // Jugar
            // 
            this.Jugar.Location = new System.Drawing.Point(395, 410);
            this.Jugar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Jugar.Name = "Jugar";
            this.Jugar.Size = new System.Drawing.Size(130, 33);
            this.Jugar.TabIndex = 46;
            this.Jugar.Text = "Invitar";
            this.Jugar.UseVisualStyleBackColor = true;
            this.Jugar.Click += new System.EventHandler(this.Jugar_Click);
            // 
            // nombre_invitado_Box
            // 
            this.nombre_invitado_Box.Location = new System.Drawing.Point(395, 376);
            this.nombre_invitado_Box.Name = "nombre_invitado_Box";
            this.nombre_invitado_Box.Size = new System.Drawing.Size(130, 22);
            this.nombre_invitado_Box.TabIndex = 48;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(392, 356);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(145, 16);
            this.label14.TabIndex = 49;
            this.label14.Text = "A quien quieres invitar?";
            // 
            // MensajeBox
            // 
            this.MensajeBox.Location = new System.Drawing.Point(569, 482);
            this.MensajeBox.Multiline = true;
            this.MensajeBox.Name = "MensajeBox";
            this.MensajeBox.Size = new System.Drawing.Size(351, 48);
            this.MensajeBox.TabIndex = 50;
            // 
            // EnviarMensaje
            // 
            this.EnviarMensaje.Location = new System.Drawing.Point(953, 487);
            this.EnviarMensaje.Name = "EnviarMensaje";
            this.EnviarMensaje.Size = new System.Drawing.Size(112, 43);
            this.EnviarMensaje.TabIndex = 51;
            this.EnviarMensaje.Text = "Enviar mensaje";
            this.EnviarMensaje.UseVisualStyleBackColor = true;
            this.EnviarMensaje.Click += new System.EventHandler(this.EnviarMensaje_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // RecibeTexto
            // 
            this.RecibeTexto.Location = new System.Drawing.Point(569, 331);
            this.RecibeTexto.Name = "RecibeTexto";
            this.RecibeTexto.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.RecibeTexto.Size = new System.Drawing.Size(496, 125);
            this.RecibeTexto.TabIndex = 53;
            this.RecibeTexto.Text = "";
            // 
            // TiempoChat
            // 
            this.TiempoChat.Interval = 1000;
            this.TiempoChat.Tick += new System.EventHandler(this.TiempoChat_Tick);
            // 
            // AcabarChatBtn
            // 
            this.AcabarChatBtn.Location = new System.Drawing.Point(953, 536);
            this.AcabarChatBtn.Name = "AcabarChatBtn";
            this.AcabarChatBtn.Size = new System.Drawing.Size(112, 43);
            this.AcabarChatBtn.TabIndex = 54;
            this.AcabarChatBtn.Text = "Acabar Chat";
            this.AcabarChatBtn.UseVisualStyleBackColor = true;
            this.AcabarChatBtn.Click += new System.EventHandler(this.AcabarChatBtn_Click);
            // 
            // radioButtonConsulta2
            // 
            this.radioButtonConsulta2.AutoSize = true;
            this.radioButtonConsulta2.Location = new System.Drawing.Point(28, 502);
            this.radioButtonConsulta2.Name = "radioButtonConsulta2";
            this.radioButtonConsulta2.Size = new System.Drawing.Size(387, 20);
            this.radioButtonConsulta2.TabIndex = 55;
            this.radioButtonConsulta2.TabStop = true;
            this.radioButtonConsulta2.Text = "Consulta 2: Dime la última frase que dijo quien acabó el chat.";
            this.radioButtonConsulta2.UseVisualStyleBackColor = true;
            // 
            // IniciarSesion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Version1.Properties.Resources.OIP;
            this.ClientSize = new System.Drawing.Size(1094, 630);
            this.Controls.Add(this.radioButtonConsulta2);
            this.Controls.Add(this.AcabarChatBtn);
            this.Controls.Add(this.RecibeTexto);
            this.Controls.Add(this.EnviarMensaje);
            this.Controls.Add(this.MensajeBox);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.nombre_invitado_Box);
            this.Controls.Add(this.Jugar);
            this.Controls.Add(this.AceptarRegistro);
            this.Controls.Add(this.contraseñaIn);
            this.Controls.Add(this.usuarioIn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.AceptarConsulta);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.Desconectar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.inicioSesion);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.usuario_Box);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "IniciarSesion";
            this.Text = "INICIO DE SESIÓN";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox usuario_Box;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button inicioSesion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Desconectar;
        private System.Windows.Forms.Button AceptarConsulta;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Button AceptarRegistro;
        private System.Windows.Forms.TextBox contraseñaIn;
        private System.Windows.Forms.TextBox usuarioIn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Jugar;
        private System.Windows.Forms.TextBox nombre_invitado_Box;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox MensajeBox;
        private System.Windows.Forms.Button EnviarMensaje;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.RichTextBox RecibeTexto;
        private System.Windows.Forms.Timer TiempoChat;
        private System.Windows.Forms.Button AcabarChatBtn;
        private System.Windows.Forms.RadioButton radioButtonConsulta2;
    }
}