﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Timers;

namespace Version1
{
    public partial class IniciarSesion : Form
    {
        Socket server;
        Thread atender;

        //Variables de cada partida

        string[] nameJugadores = new string[6]; //Vector con los nombres de los 6 jugadores 
        int invitar = 0;
        int jugadores = 0;
        int idPartida;
        int numJugadoresP = 0;
        int jugador;
        int minutos = 0;
        string ultimaLinea;

        public IniciarSesion()
        {
            InitializeComponent();
           
        }

         private void Form2_Load(object sender, EventArgs e) //Iniciamos la conexión
        {
            //Creamos un IDEndPoint con el IP y puerto del servidor
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 9070);

            //Acceso shiva:
            //IPAddress direc = IPAddress.Parse("147.83.117.22");
            //IPEndPoint ipep = new IPEndPoint(direc, puerto);

            //Creamos el socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectar el socket
                MessageBox.Show("Se ha establecido conexión con el servidor");
            }
            catch (SocketException exc)
            {
                MessageBox.Show("No se ha podido conectar con el servidor");
                return;
            }
            //pongo en marcha el thread
            ThreadStart ts = delegate { AtenderServidor(); };
            atender = new Thread(ts);
            atender.Start();
        }

        private void AtenderServidor() // empezamos el bucle para atender los mensajes del Servidor
        {

            while (true)
            {
                //Recibimos la respuesta del servidor
                byte[] msg2 = new byte[80];
                this.server.Receive(msg2);
                string mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                string[] trozos = mensaje.Split('/'); //partimos el mensaje por las /

                Console.WriteLine("Trozo 0 = " + trozos[0]);
                int codigo = Convert.ToInt32(trozos[0]);//convertimos codigo a entero
               

                switch (codigo)
                {
                    case 0: //Desconexión
                        
                        this.BackColor = Color.LightSlateGray;
                        dataGridView1.Columns.Clear();
                        MessageBox.Show("Te has desconectado, hasta la próxima!");
                        //Cerramos la conexión
                        server.Shutdown(SocketShutdown.Both);
                        server.Close();
                        atender.Abort();
                        this.Close();
                        

                        break;

                    case 1: //Inicio de sesión

                        if (trozos[1] == "INCORRECTO")
                        {
                            MessageBox.Show("Nombre de usuario o contraseña incorrecta.");
                        }
                        else
                        {
                            MessageBox.Show("Bienvenido " + usuario_Box.Text + "!");
                            this.BackColor = Color.LightGreen;
                        }
                        break;

                     case 2: //Registro

                        if (mensaje == "2/Registrado correctamente")
                        {
                            MessageBox.Show("Usuario registrado correctamente");
                        }
                        else if (mensaje == "2/No se ha podido registrar al usuario")
                        {
                            MessageBox.Show("No se ha podido insertar el usuario");
                        }
                        else
                        {
                            MessageBox.Show("No se ha podido acceder a la base de datos");
                            
                        }
                        break;

                    case 3: //Consulta 1, muestra message box con la duracion del chat

                        //Recibimos la respuesta del servidor
                        int duracion_ultima_part = Convert.ToInt32(trozos[1]);
                        MessageBox.Show("El ultimo chat ha durado: " + duracion_ultima_part + " minutos");

                        break;


                    case 5: //Lista de conectados, añade al data grid view la lista de conectados

                        Invoke(new Action(() =>
                        {
                            //Recibimos la respuesta del servidor
                            dataGridView1.Rows.Clear();
                             int num = Convert.ToInt32(trozos[1]);
                             dataGridView1.RowCount = num;
                             for (int i = 0; i < num; i++)
                             {
                                dataGridView1.Rows[i].Cells[0].Value = trozos[i + 2];
                             }
                             this.dataGridView1.Rows[0].Cells[0].Selected = false;
                        }));
                        break;


                    case 6: //Consulta2, ultima frase que dijo quien inalizo el chat

                        //Recibimos la respuesta del servidor
                        string ultima_frase = trozos[1];
                        MessageBox.Show("La última frase que dijo quien finalizó el chat fue: " + ultima_frase);

                        break;

                    case 7: //Invitación, te muestra un message box para aceptar o rechazar la invitación, y envia mensaje al servidor: 8/nombre_invitado/nuestro nombre/ si o no.

                        var result = MessageBox.Show("Aceptas jugar con:" + trozos[1],"aceptacion", MessageBoxButtons.YesNo);

                        Invoke(new Action(() =>
                        {
                            if (result == DialogResult.Yes)
                            {
                                // Enviamos al servidor el nombre del usuario (devuelve 10/nombre_Invitado/nombre_Invitador/Yes)       
                                byte[] msg = System.Text.Encoding.ASCII.GetBytes("8/" + trozos[1] + "/" + trozos[2] + "/Yes");
                                server.Send(msg);
                                //Ocultamos para esperar a que empiece la partida. 
                                nombre_invitado_Box.Text = trozos[1];
                                MensajeBox.Visible = true;
                                EnviarMensaje.Visible = true;
                               
                     

                            }
                            if (result == DialogResult.No)
                            {
                                byte[] msg = System.Text.Encoding.ASCII.GetBytes("8/" + trozos[1] + "/" + trozos[2] + "/No");
                                server.Send(msg);
                            }
                        }));
                        break;

                    case 8: //Respuesta de la invitación, muestra message box conforme a aceptado la invitacion o no.

                        Invoke(new Action(() =>
                        {
                            if (trozos[1] == "Si")
                            {
                                idPartida = Convert.ToInt32(trozos[2]);

                                MessageBox.Show("Ha aceptado la invitación " + trozos[4], "invitacion", MessageBoxButtons.OK);
                                nameJugadores[0] = trozos[3];//El jugador que invita 
                                nameJugadores[1] = trozos[4]; //Segundo Jugador
                                Invoke(new Action(() =>
                                {
                                    TiempoChat.Interval = 1000;
                                    TiempoChat.Start();

                                }));
                           
                            }
                            else
                            {
                                MessageBox.Show(trozos[2]);
                            }

                            this.dataGridView1.Rows[0].Cells[0].Selected = false;
                        }));
                        break;

                    case 9://Muestra mensajes en el Rich Box que nos estan enviando.
                        Invoke(new Action(() =>
                        {
                            RecibeTexto.AppendText("-" + " " + trozos[1] + ":" + " " + trozos[3] + Environment.NewLine);
                            // Seleccionar y cambiar el color de trozos[1] a verde
                            int startIndex = RecibeTexto.Text.LastIndexOf(trozos[1]);
                            int length = trozos[1].Length;

                            if (startIndex != -1)
                            {
                                RecibeTexto.Select(startIndex, length);
                                RecibeTexto.SelectionColor = Color.Green;
                            }
                        }));
                        break;

                    case 10://acaba la partida y borra la información

                        RecibeTexto.Clear();
                        nombre_invitado_Box.Clear();
                        
                        break;

                }
            }

        }

        private void inicioSesion_Click(object sender, EventArgs e)// Al clicar el boton de iniciar session envia código al servidor para iniciar sesion asi: 1/usuario/contraseña
        {
            string mensaje = "1/" + usuario_Box.Text + "/" + textBox2.Text;
            // Enviamos al servidor el mensjae
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
               
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Desconectar_Click(object sender, EventArgs e)// Al clicar el boton de desconectar envia código al servidor para desconectarse asi: 0/
        {
            string mensaje = "0/";
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

     
        private void AceptarConsulta_Click(object sender, EventArgs e)// Al clicar el boton de aceptar consulta envia código al servidor para consultar, ya sea el tiempo que seria asi: 3/ o la ultima frase dicha por quien acabó el chat que seria 6/
        {
            if (radioButton2.Checked)
            {
                string mensaje = "3/";
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

            }

            if (radioButtonConsulta2.Checked)
            {
                string mensaje = "6/";
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

            }
        }

        private void AceptarRegistro_Click(object sender, EventArgs e) // Al clicar el boton de resgistro envia código al servidor para registrarse asi: 2/usuario/contraseña
        {
            if (((usuarioIn.Text.Length > 1) && (contraseñaIn.Text.Length > 1)) && ((usuarioIn.Text != "") && (contraseñaIn.Text != ""))) //Que tenga un mínimo de longitud y no esté en blanco
            {
                string mensaje = "2/" + usuarioIn.Text + "/" + contraseñaIn.Text;
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else
            {
                MessageBox.Show("El nombre debe tener más de un caracter");
            }
        }

        private void Jugar_Click(object sender, EventArgs e) // Al clicar el boton de invitar envia código al servidor para invitar a quien queremos asi: 7/nuestro usuario/el del invitado
        {
            string mensaje = "7/" + usuario_Box.Text + "/" + nombre_invitado_Box.Text;
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            nameJugadores[jugadores] = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();

            if (usuarioIn.Text == nameJugadores[jugadores])
            {
                MessageBox.Show("No puedes autoinvitarte");
            }
            else
            {
                string mensaje = "7/" + usuarioIn.Text + "/" + nameJugadores[jugadores];
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                jugadores++;
            }
            
        }

        private void EnviarMensaje_Click(object sender, EventArgs e) // Al clicar el boton de enviar mensaje envia código al servidor con el mensaje y el nombre del invitado y el nuestro asi: 9/nuestro usuario/el invitado/mensaje
        {
            string mensaje = "9/" + usuario_Box.Text + "/" + nombre_invitado_Box.Text + "/" + MensajeBox.Text;
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // añade mensaje en una nueva linea del rich Box
            RecibeTexto.AppendText("- Me"+ ":" + " "+ MensajeBox.Text + Environment.NewLine);

            int startIndex = RecibeTexto.Text.LastIndexOf("Me");
            int length = "Me".Length;

            if (startIndex != -1)
            {
                RecibeTexto.Select(startIndex, length);
                RecibeTexto.SelectionColor = Color.BlueViolet;
            }

            ultimaLinea = "-" + usuario_Box.Text + ": " + MensajeBox.Text;

            MensajeBox.Clear();

            
         
        }

        private void AcabarChatBtn_Click(object sender, EventArgs e) // Al clicar el boton de acabar chat envia código al servidor con la ultima linea que dijo el que acabó el chat y el tiemp que duró asi: 10/ultima linea/tiempo
        {
            TiempoChat.Stop();
            // Enviamos al servidor el mensaje
            string mensaje = "10/" + ultimaLinea + "/" + minutos ;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            

            RecibeTexto.Clear();
            nombre_invitado_Box.Clear();

        }

        private void TiempoChat_Tick(object sender, EventArgs e)//cada minuto se actualiza y suma 1, por tanto cuenta cuantos minutos dura el chat
        {
            minutos = minutos + 1;
        }
    }
}
